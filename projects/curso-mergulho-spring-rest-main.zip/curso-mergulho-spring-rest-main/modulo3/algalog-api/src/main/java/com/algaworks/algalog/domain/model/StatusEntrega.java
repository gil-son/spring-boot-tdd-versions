package com.algaworks.algalog.domain.model;

public enum StatusEntrega {

	PENDENTE, FINALIZADA, CANCELADA
	
}
